# Databricks notebook source
raw_folder_path="/mnt/azuremysqlstorage/raw-files"

# COMMAND ----------

