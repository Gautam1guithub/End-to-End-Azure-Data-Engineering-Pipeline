# Databricks notebook source
storage_account_name = "azuremysqlstorage"
container_name = "raw-files"
mount_point = f"/mnt/{storage_account_name}/{container_name}"


# COMMAND ----------

client_id='037596d9-f9b2-4317-955d-768e9fb71324'
tenant_id='3e6d9bce-2462-4a32-927a-6eb4b15fb02a'
client_secret='Wg08Q~~Drfl4rVgDy2aPr0oS2.w8NpQK0zw~~bns'

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": "Wg08Q~~Drfl4rVgDy2aPr0oS2.w8NpQK0zw~~bns",
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}

# COMMAND ----------

dbutils.fs.mount(
  source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
  mount_point = mount_point,
  extra_configs = configs
)

# COMMAND ----------

